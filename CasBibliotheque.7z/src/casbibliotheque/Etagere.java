package casbibliotheque;

public class Etagere {
	//Attribut
	private int numero;
	
	//M�thodes
	/**
	 * constructeur de Etagere
	 * @param numero :  le numero de l'etagere
	 */
	Etagere(int numero) {
		this.numero = numero;
	}
	
	/**
	 * le getter de Etagere
	 */
	int getNumeroEtagere(){
		return this.numero;
	}

}
